package jdbcpack;
import java.sql.*;
public class DbConnection {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj =  DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "root", "master");
			if(conObj!=null)
				System.out.println("Connected....");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}