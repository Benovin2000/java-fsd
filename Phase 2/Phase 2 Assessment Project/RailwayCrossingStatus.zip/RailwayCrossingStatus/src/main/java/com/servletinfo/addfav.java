package com.servletinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.model.userfavourites;
import com.service.railwayoperations;

/**
 * Servlet implementation class addfav
 */
@WebServlet("/addfav")
public class addfav extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addfav() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String userid = request.getParameter("txtuserid");
		String crid = request.getParameter("txtcrid");
		String cname = request.getParameter("txtname");
		String caddr = request.getParameter("txtaddress");
		String cland = request.getParameter("txtland");
		String ctrain = request.getParameter("txttrain");
		String cperson = request.getParameter("txtperson");
		String status = request.getParameter("status");
		
		System.out.println(userid);
		System.out.println(crid);

		userfavourites uf = new userfavourites();
		uf.setFuserid(Integer.parseInt(userid));
		uf.setFcrid(Integer.parseInt(crid));
		uf.setfCrossingname(cname);
		uf.setFaddress(caddr);
		uf.setFlandmark(cland);
		uf.setFtrainschedule(ctrain);
		uf.setFincharge(cperson);
		uf.setFstatus(status);
		
		railwayoperations ro = new railwayoperations();
		
		String res = ro.AddToFav(uf);
		if(res.equals("Success"))
			response.sendRedirect("userhome.jsp");
	}

}
