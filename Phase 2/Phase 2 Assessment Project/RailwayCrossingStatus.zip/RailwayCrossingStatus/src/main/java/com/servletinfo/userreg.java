package com.servletinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.crossings;
import com.model.user;
import com.service.railwayoperations;

/**
 * Servlet implementation class userreg
 */
@WebServlet("/userreg")
public class userreg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userreg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String uname = request.getParameter("txtusername");
		String email = request.getParameter("txtemail");
		String password = request.getParameter("txtpassword");
	
		user ur = new user();
		ur.setUsername(uname);
		ur.setEmail(email);
		ur.setPassword(password);
		
		railwayoperations ro = new railwayoperations();
		
		String res = ro.AddNewUser(ur);
		if(res.equals("Success"))
			response.sendRedirect("userlogin.jsp");
	}

}
