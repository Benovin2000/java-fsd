package com.servletinfo;

import com.model.*;
import com.service.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class addcrossing
 */
@WebServlet("/addcrossing")
public class addcrossing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addcrossing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String cname = request.getParameter("txtname");
		String caddr = request.getParameter("txtaddress");
		String cland = request.getParameter("txtland");
		String ctrain = request.getParameter("txttrain");
		String cperson = request.getParameter("txtperson");
		String status = request.getParameter("status");

		crossings cr = new crossings();
		cr.setCrossingname(cname);
		cr.setAddress(caddr);
		cr.setLandmark(cland);
		cr.setTrainschedule(ctrain);
		cr.setIncharge(cperson);
		cr.setStatus(status);
		
		railwayoperations ro = new railwayoperations();
		
		String res = ro.AddNewCrossing(cr);
		if(res.equals("Success"))
			response.sendRedirect("adminhome.jsp");
	}

}


