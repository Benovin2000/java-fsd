

	package com.model;

	import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name = "Favourites")
	public class userfavourites {
		
		@Id
		@GeneratedValue
		private int favid;
		private int fuserid;
		private int fcrid;
		private String fCrossingname;
		private String faddress;
		private String flandmark;
		private String ftrainschedule;
		private String fincharge;
		private String fstatus;
		
		
		public int getFavid() {
			return favid;
		}
		public void setFavid(int favid) {
			this.favid = favid;
		}
		public int getFuserid() {
			return fuserid;
		}
		public void setFuserid(int fuserid) {
			this.fuserid = fuserid;
		}
		public int getFcrid() {
			return fcrid;
		}
		public void setFcrid(int fcrid) {
			this.fcrid = fcrid;
		}
		public String getfCrossingname() {
			return fCrossingname;
		}
		public void setfCrossingname(String fCrossingname) {
			this.fCrossingname = fCrossingname;
		}
		public String getFaddress() {
			return faddress;
		}
		public void setFaddress(String faddress) {
			this.faddress = faddress;
		}
		public String getFlandmark() {
			return flandmark;
		}
		public void setFlandmark(String flandmark) {
			this.flandmark = flandmark;
		}
		public String getFtrainschedule() {
			return ftrainschedule;
		}
		public void setFtrainschedule(String ftrainschedule) {
			this.ftrainschedule = ftrainschedule;
		}
		public String getFincharge() {
			return fincharge;
		}
		public void setFincharge(String fincharge) {
			this.fincharge = fincharge;
		}
		public String getFstatus() {
			return fstatus;
		}
		public void setFstatus(String fstatus) {
			this.fstatus = fstatus;
		}
		
	}

		
