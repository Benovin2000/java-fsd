package com.servletinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.crossings;
import com.service.railwayoperations;

/**
 * Servlet implementation class updatecrossing
 */
@WebServlet("/updatecrossing")
public class updatecrossing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updatecrossing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String crid = request.getParameter("crid");
		String cname = request.getParameter("txtname");
		String caddr = request.getParameter("txtaddress");
		String cland = request.getParameter("txtland");
		String ctrain = request.getParameter("txttrain");
		String cperson = request.getParameter("txtperson");
		String status = request.getParameter("status");

		crossings cr = new crossings();
		cr.setCrossingname(cname);
		cr.setAddress(caddr);
		cr.setLandmark(cland);
		cr.setTrainschedule(ctrain);
		cr.setIncharge(cperson);
		cr.setStatus(status);
		cr.setCrid(Integer.parseInt(crid));
		
		railwayoperations ro = new railwayoperations();
		
		String res = ro.UpdateCrossinginfo(cr);
		if(res.equals("Success"))
			response.sendRedirect("adminhome.jsp");
	}

}
