package com.service;

import javax.persistence.*;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dbcon.*;
import com.model.*;

public class railwayoperations {


	private SessionFactory sfactory = null;
	public railwayoperations()
	{
		sfactory = hyberconfig.getSessionFactory();
	}
	
	public String AddNewCrossing(crossings cr)
	{
		String result = "error";
	
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(cr);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}
	
	public List<crossings>  ShowAll()
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from crossings");
		List<crossings> call = qry.getResultList();
		return call;
	}
	
	public boolean DeleteCrossing(int crid)
	{
		
		boolean b = false;
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Delete from crossings where crid=:crid");
		qry.setParameter("crid", crid);
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			b = true;
		
		return b;
	}
	
	public crossings  GetCrossingDetails(int crid)
	{
		crossings cr = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from crossings where crid=:r");
		qry.setParameter("r", crid);;
		List<crossings> sall = qry.getResultList();
		
		if(!sall.isEmpty())
			cr = sall.get(0);
		
		return cr;
	}
	
	public String UpdateCrossinginfo(crossings cr)
	{
		String result = "error";
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Update crossings set Crossingname=:cn, address=:adr, landmark=:la, trainschedule=:tr, incharge=:in, status=:st where crid=:id");
		qry.setParameter("cn", cr.getCrossingname());
		qry.setParameter("adr", cr.getAddress());
		qry.setParameter("la", cr.getLandmark());
		qry.setParameter("tr", cr.getTrainschedule());
		qry.setParameter("in", cr.getIncharge());
		qry.setParameter("st", cr.getStatus());
		qry.setParameter("id", cr.getCrid());
	
		System.out.println(cr.getCrid() + cr.getStatus());
		
		
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			result = "Success";
		
		return result;
	}
	
	public List<crossings>  SearchCrossing(String str)
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from crossings where Crossingname like :str");
		qry.setParameter("str", "%"+str+"%");
		List<crossings> call = qry.getResultList();
		return call;
	}
	
	public int NoOfCrossings()
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from crossings");
		List<crossings> call = qry.getResultList();
		return call.size();
	}
	
	public user  UserCheck(String email, String pwd)
	{
		user ur = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from user where email=:em and password=:pwd");
		qry.setParameter("em", email);
		qry.setParameter("pwd", pwd);
		List<user> sall = qry.getResultList();
		
		if(!sall.isEmpty())
			ur = sall.get(0);
		
		return ur;
	}
	
	public String AddNewUser(user ur)
	{
		String result = "error";
	
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(ur);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}
	
	public String AddToFav(userfavourites uf)
	{
		String result = "error";
	
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(uf);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}
	
	public List<userfavourites>  ShowFav(int fuserid)
	{
		userfavourites uf = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from userfavourites where fuserid=:r");
		qry.setParameter("r", fuserid);;
		List<userfavourites> sall = qry.getResultList();
		
		return sall;
}

}
