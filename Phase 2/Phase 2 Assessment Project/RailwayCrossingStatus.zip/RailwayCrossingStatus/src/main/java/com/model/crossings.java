package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CrossingInfo")
public class crossings {

	@Id
	@GeneratedValue
	private int crid;
	private String Crossingname;
	private String address;
	private String landmark;
	private String trainschedule;
	private String incharge;
	private String status;

	public int getCrid() {
		return crid;
	}

	public void setCrid(int crid) {
		this.crid = crid;
	}

	public String getCrossingname() {
		return Crossingname;
	}

	public void setCrossingname(String crossingname) {
		Crossingname = crossingname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getTrainschedule() {
		return trainschedule;
	}

	public void setTrainschedule(String trainschedule) {
		this.trainschedule = trainschedule;
	}

	public String getIncharge() {
		return incharge;
	}

	public void setIncharge(String incharge) {
		this.incharge = incharge;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
