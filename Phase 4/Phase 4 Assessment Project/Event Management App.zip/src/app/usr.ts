export class Usr {

        id:string;
        uname:string;
        password:string;
        
    
        constructor(id:string, un:string, ps:string, )
        {
            this.id = id;
            this.uname = un;
            this.password = ps;
        }
        
    
}
