import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Emp } from '../emp';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-newemp',
  templateUrl: './newemp.component.html',
  styleUrls: ['./newemp.component.css']
})
export class NewempComponent implements OnInit {

  constructor(private empServ:EmpService, private router:Router) { }

  ngOnInit(): void {
  }
  emp:Emp = new Emp(null,"","","");
  msg:string = "";
  
  addNewEmployee(frm:any)
  {
      if(frm.valid)
      {
      this.empServ.newEmployee(this.emp).subscribe(data=>{
        console.log(data);
        //alert("New Employee is Added Successfully...");
        this.router.navigate(['emp']);
      });
    }
    else
      this.msg = "Invalid Form";
  }
}
