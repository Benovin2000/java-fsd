import { Usr } from './usr';

describe('Usr', () => {
  it('should create an instance', () => {
    expect(new Usr()).toBeTruthy();
  });
});
