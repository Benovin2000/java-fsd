import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmpService } from '../emp.service';
import { Emp } from '../emp';

@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UpateEmpComponent implements OnInit {

  constructor(private empServ:EmpService, private route:ActivatedRoute, 
    private router:Router) { }

  id:number;
  emp:Emp;

  ngOnInit(): void {
    this.showEmpInfo();
  }

  showEmpInfo()
  {
    this.id = this.route.snapshot.params['id'];
    //alert(this.id);
    this.emp = new Emp(null,"","",""); 
    this.empServ.SearchEmp(this.id).subscribe(data=>{
      //console.log(data);
      this.emp = data;
    });  
  }

  UpdateEmployeeInfo()
  {
    this.empServ.UpdateEmp(this.id, this.emp).subscribe(data=>{
      this.router.navigate(['emp']);
    })
  }

}
