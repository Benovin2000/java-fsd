import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Emp } from '../emp';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit {

  constructor(private empServ:EmpService, private route:ActivatedRoute, private router:Router) { }

  id:number;
  emp:Emp;
  ngOnInit(): void {
    this.showEmpInfo();
    }

    showEmpInfo()
    {
      this.id = this.route.snapshot.params['id'];
      this.emp = new Emp(null,"","",""); 
      this.empServ.SearchEmp(this.id).subscribe(data=>{
        console.log(data);
        this.emp = data;
      });  
    }

    DeleteEmployeeInfo(id:number)
    {
      this.empServ.DeleteEmp(id).subscribe(data=>{
        this.router.navigate(['emp']);
      });
    }

    UpdateEmpInfo(id:number)
  {
    this.router.navigate(['updateemp', id]);
  }

  returntoemp(){
    this.router.navigate(['emp']);
  }
  }

