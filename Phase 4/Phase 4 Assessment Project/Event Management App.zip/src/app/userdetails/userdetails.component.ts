import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Usr } from '../usr';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {

  constructor(private empServ:EmpService, private route:ActivatedRoute, 
    private router:Router) { }

    id:string;
    usr:Usr;
    pwd:string;

  ngOnInit(): void {
    this.showUsrInfo();
    
  }
  

  showUsrInfo()
  {
    this.id = this.route.snapshot.params['id'];
    this.usr = new Usr("","",""); 
    this.empServ.SearchUsr(this.id).subscribe(data=>{
      this.usr = data;
      this.pwd=this.usr.password
    });  
  }

  UpdatePassword()
  {
    this.empServ.UpdateUsr(this.id, this.usr).subscribe(data=>{
      alert("Password Updated.. Please Login again");
      this.router.navigate(['login']);
    })
  }
}
