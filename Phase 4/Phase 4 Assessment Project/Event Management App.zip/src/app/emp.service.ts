import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Emp } from './emp';
import { Usr } from './usr';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  constructor(private httpClient: HttpClient) { }

  private apiUrl = "http://localhost:3000/employees";
  private usrUrl = "http://localhost:3000/userinfo"

  getAllEmployees()
  {
    return this.httpClient.get<Emp[]>(this.apiUrl);
  }
  
  newEmployee(employee:Emp):Observable<Object>{
    return this.httpClient.post(`${this.apiUrl}`, employee);
  }

  SearchEmp(id:number) : Observable<Emp>{
    return this.httpClient.get<Emp>(`${this.apiUrl}/${id}`);
  }
  
  DeleteEmp(id:number) : Observable<Object>{
    return this.httpClient.delete(`${this.apiUrl}/${id}`);
  }
  
  UpdateEmp(id:number, emp:Emp) : Observable<Object>{
    return this.httpClient.put(`${this.apiUrl}/${id}`, emp);
  }

  UpdateUsr(id:string, usr:Usr) : Observable<Object>{
    return this.httpClient.put(`${this.usrUrl}/${id}`, usr);
  }

  getAllUsr()
  {
    return this.httpClient.get<Usr[]>(this.usrUrl);
  }

  SearchUsr(id:string) : Observable<Usr>{
    return this.httpClient.get<Usr>(`${this.usrUrl}/${id}`);
  }

}
