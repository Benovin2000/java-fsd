import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmpService } from '../emp.service';
import { Router } from '@angular/router';
import { Usr } from '../usr';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {
  empinfo:Emp[] = []
  fname:any;
  usrinfo:Usr[] = []
  constructor(private service:EmpService, private router:Router) { }

  ngOnInit(): void {
    this.service.getAllEmployees().subscribe(data=>{
      this.empinfo = data;
    });
    this.service.getAllUsr().subscribe(data=>{
      this.usrinfo = data;
    })
  }
  getOneEmpDetails(id:number)
  {
    this.router.navigate(['oneemp', id]);
  }
  addNew()
  {
    this.router.navigate(['newemp']);
  }
  
  getOneUsr(id:string)
  {
    this.router.navigate(['newpass', id]);
  }

}
