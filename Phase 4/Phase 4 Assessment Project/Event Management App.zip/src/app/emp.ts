export class Emp {
    id:number;
    fname:string;
    lname:string;
    email:string;

    constructor(id:number, fn:string, ln:string, em:string)
    {
        this.id = id;
        this.fname = fn;
        this.lname = ln;
        this.email = em;
    }
    
}
