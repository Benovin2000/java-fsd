import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  fname:string = "This is Binding"
  url:string = "http://www.facebook.com/";

  demofun()
  {
    this.fname = "Regal";
    //alert("this is an alert box");
  }
}
