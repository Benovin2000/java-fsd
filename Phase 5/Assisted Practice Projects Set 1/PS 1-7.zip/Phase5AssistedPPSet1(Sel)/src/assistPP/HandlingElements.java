package assistPP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

public class HandlingElements {

	public static void main(String[] args) throws Exception{
		
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/WeekendDesigningSessions/Ex5.html");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement chkbox1 = driver.findElement(By.name("chk1"));
		chkbox1.click();  // it will check option
		Thread.sleep(2000);
		if(chkbox1.isSelected())
		{
			String val = chkbox1.getAttribute("value");
			System.out.println("Given Value is : " + val);
			chkbox1.click(); // uncheck
			System.out.println("Option Unchecked");

		}
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize(); // maximizes the window automatically
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.id("email"));
		if(element.isDisplayed())
		{
			if(element.isEnabled())
			{
				element.sendKeys("abc@gmail.com"); // sending text to the textbox
				String enteredText =  element.getAttribute("value");
				System.out.println("Given Mail : " + enteredText);
				Thread.sleep(3000);
				element.clear(); // clears the text box value
				// clicking hyperlink
				driver.findElement(By.linkText("Forgotten password?")).click();	// click event		
			}
			else
				System.out.println("Textbox is Disabled");
		}
		else
			System.out.println("Textbox is not Visiable");
		
		driver.get("file:///C:/WeekendDesigningSessions/Ex5.html");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement radiobox1 = driver.findElement(By.id("malegen"));
		radiobox1.click();
		if(radiobox1.isSelected())
		{
			System.out.println("Gender Value is : " + radiobox1.getAttribute("value"));
		}
		Thread.sleep(2000);
		WebElement radiobox2 = driver.findElement(By.id("femalegen"));
		radiobox2.click();
		if(radiobox2.isSelected())
		{
			System.out.println("Gender Value is : " + radiobox2.getAttribute("value"));
		}	
		
		WebElement txtpname = driver.findElement(By.id("txtPerson"));
		txtpname.sendKeys("Testing");
		Thread.sleep(2000);
		WebElement button = driver.findElement(By.id("regBtn"));
		button.click();
		Thread.sleep(2000);
		System.out.println("Given Value is : " + driver.findElement(By.id("res")).getText());
		
		
		
		
	}
}
