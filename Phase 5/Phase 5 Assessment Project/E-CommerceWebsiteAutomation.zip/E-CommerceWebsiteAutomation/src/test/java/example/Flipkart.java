package example;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Flipkart {
	
	private WebDriver driver=null;
	
	
	@Parameters("browserName")
	@BeforeTest
	public void InitalizeDriver(int browserName)
	{// 1 = Chrome  2 = Edge
		switch(browserName)
		{
		case 1:
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			break;
			
		case 2:
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			driver.manage().window().setSize(new org.openqa.selenium.Dimension(1366,768));
			break;
		}
		
	}
	
	 @Test(priority=1)
	public void LaunchingWebsite() {
		
		driver.get("https://www.flipkart.com/");
		driver.findElement(By.xpath("//a[@href='/pages/terms' ]")).sendKeys(Keys.ESCAPE);
		
		//href="/pages/terms"
	} 
	
	@Test(priority=2)
	public void PageLoadTime() {
		
		long startTime = System.currentTimeMillis();
		driver.get("https://www.flipkart.com/");
		long endTime = System.currentTimeMillis();
		
		long pageLoadTime = endTime - startTime;
		System.out.println("Page load time: " + pageLoadTime + " milliseconds");
	}
	
	@Test(priority=3)
	public void SearchForProduct() throws Exception {
		
		WebElement element =driver.findElement(By.xpath("//input[@title='Search for products, brands and more' ]"));
		element.sendKeys("iphone 13", Keys.ENTER);
		
		Thread.sleep (3000);
		
		//title="Search for products, brands and more"
	}
	
	@Test(priority=4, dependsOnMethods= {"LaunchingWebsite","SearchForProduct"})
	public void ImageVisibilityTest() throws Exception {
		
	    // Get the height of the browser window
	    long windowHeight = (Long) ((JavascriptExecutor) driver).executeScript("return window.innerHeight;");

	    // Get all image elements on the page
	    List<WebElement> imageElements = driver.findElements(By.xpath("//img[@class='_396cs4' and @alt='APPLE iPhone 13 (Starlight, 128 GB)']"));

	    // Iterate through each image element
	    for (WebElement imageElement : imageElements) {
	        // Check if the image is displayed
	        boolean isDisplayed = imageElement.isDisplayed();

	        // Check if the image is loaded (assuming it's visible within the current screen height)
	        boolean isLoaded = isDisplayed && imageElement.getLocation().getY() < windowHeight;

	        // Assert that the image is loaded and visible till the screen height
	        Assert.assertTrue(isLoaded, "Image is not loaded or visible till the screen height.");
	    }
	}
	
	@Test(priority=5, dependsOnMethods= {"LaunchingWebsite","SearchForProduct"})
	public void ScrollFeatureTest() {
		

	    // Check if the page has a vertical scrollbar
	    boolean hasVerticalScrollbar = (Boolean) ((JavascriptExecutor) driver).executeScript(
	        "return document.documentElement.scrollHeight > document.documentElement.clientHeight;");

	    // Assert that the page has a vertical scrollbar
	    Assert.assertTrue(hasVerticalScrollbar, "Page does not have a vertical scrollbar.");
	}
	
	@Test(priority=6, dependsOnMethods= {"LaunchingWebsite","SearchForProduct"})
	public void ScrollRefreshFrequency() {


	    // Get the initial page height before scrolling
	    long initialPageHeight = (Long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight;");

	    // Scroll the page down
	    int scrollIncrement = 800;
	    long totalScrollDistance = 0;
	    int refreshCounter = 0;

	    do {
	        // Scroll the page by the scroll increment
	        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, " + scrollIncrement + ");");

	        try {
	            Thread.sleep(1000); // 1 second
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Get the current page height after scrolling
	        long currentPageHeight = (Long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight;");

	        // Check if the page height increased, indicating a content refresh
	        if (totalScrollDistance < initialPageHeight) {
	            totalScrollDistance += scrollIncrement;
	        }
	        
	        if (currentPageHeight == initialPageHeight ) {
	        	refreshCounter=0;
	        }
	        else refreshCounter++;
	        	
	        
	    } while (totalScrollDistance < 8500);
	    
	    

	    // Print the refresh frequency
	    System.out.println("Content refresh frequency while scrolling: " + refreshCounter + " times.");

	}
	
	@Test(priority=7, dependsOnMethods= {"LaunchingWebsite","SearchForProduct"})
	public void ImageDownloadAndVisibility() {

	    // Find the image element by its locator
	    WebElement imageElement = driver.findElement(By.xpath("//img[@alt='APPLE iPhone 13 ((PRODUCT)RED, 256 GB)']")); // Replace with the actual locator for the image

	    // Get the image source before scrolling to check if it's downloaded
	    String imageSourceBeforeScroll = imageElement.getAttribute("src");

	    // Scroll the page down to bring the image into view
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", imageElement);

	    try {
	        Thread.sleep(2000); // 2 seconds
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }

	    // Check if the image source is same after scrolling, indicating that it got downloaded
	    String imageSourceAfterScroll = imageElement.getAttribute("src");
	    Assert.assertEquals(imageSourceBeforeScroll, imageSourceAfterScroll, "Image download verification failed.");

	    // Check if the image is displayed on the page after scrolling
	    boolean isDisplayed = imageElement.isDisplayed();
	    Assert.assertTrue(isDisplayed, "Image is not displayed on the page.");
	}
	
	@Test(priority=8, dependsOnMethods= {"LaunchingWebsite"})
	public void NavigationToBottomOfPage() {
		
		driver.navigate().to("https://www.flipkart.com/");
	    
		try {
	        Thread.sleep(3000); // 2 seconds
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }

	    // Scroll to the bottom of the page
	    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");

	    // Wait for a short duration to allow the page to scroll (adjust this wait time as needed)
	    try {
	        Thread.sleep(3000); // 2 seconds
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }

	    // Get the current vertical scroll position as a Long
	    //Long currentScrollPosition = (Long) ((JavascriptExecutor) driver).executeScript("return window.pageYOffset;");
	    Double DoublecurrentScrollPosition = (Double) ((JavascriptExecutor) driver).executeScript("return window.pageYOffset;");
	    Long currentScrollPosition = (new Double(DoublecurrentScrollPosition)).longValue();
	    
	    // Get the maximum vertical scroll position (scrollHeight - innerHeight) as a Long
	    Long maxScrollPosition = (Long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight - window.innerHeight;");
	    
	    // Verify if the current scroll position is equal to the maximum scroll position
	    Assert.assertEquals(currentScrollPosition, maxScrollPosition, "Page navigation to the bottom failed.");
	}


}
