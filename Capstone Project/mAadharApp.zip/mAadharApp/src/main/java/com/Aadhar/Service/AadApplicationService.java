package com.Aadhar.Service;

import java.util.List;

import com.Aadhar.models.AadApplication;



public interface AadApplicationService {

	public String AddNewApplication(AadApplication app);
	public List<AadApplication> ShowAllApplications();
	public AadApplication  SearchApplication(int appid);
	public String UpdateApplication(AadApplication app);
	public void DeleteApplication(int appid);
	public List<AadApplication> findByStatus(String status);
	public AadApplication findByCid(int cid);
	public List<AadApplication> findByType(String type); 
}
