package com.Aadhar.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Aadhar.models.AadCitizens;
import com.Aadhar.repo.AadCitizensRepo;


@Service
public class AadCitizensServiceImp implements AadCitizensService {
	
	@Autowired
	AadCitizensRepo cir;

	@Override
	public String AddNewCitizen(AadCitizens cit) {
		String res = "err";
		if(cit!=null)
		{
			cir.save(cit);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public List<AadCitizens> ShowAllCitizens() {
		List<AadCitizens>  citall = cir.findAll();
		return citall;
	}

	@Override
	public AadCitizens SearchCitizen(int cid) {
		Optional<AadCitizens> cit = cir.findById(cid); 
		if(cit.isPresent())
			return cit.get();
		
		return null;
	}

	@Override
	public String ModifyCitizen(AadCitizens cit) {
		String res = "err";
		if(cit!=null)
		{
			cir.saveAndFlush(cit);  // modify
			res = "Success";
		}
		return res;
	}

	@Override
	public void DeleteCitizen(int cid) {
		cir.deleteById(cid);
		
	}

	@Override
	public AadCitizens findByName(String name) {
		AadCitizens cit = cir.findByName(name);
		if(cit!=null)
			return cit;
		
		return null;
	}

	

}