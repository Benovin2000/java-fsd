package com.Aadhar.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Aadhar.models.AadCard;


@Repository
public interface AadCardRepo extends JpaRepository<AadCard, Integer> {
	
	public AadCard findByAadcid(int aadcid);
}

