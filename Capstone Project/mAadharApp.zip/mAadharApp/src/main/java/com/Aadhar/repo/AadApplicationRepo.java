package com.Aadhar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Aadhar.models.AadApplication;

@Repository
public interface AadApplicationRepo extends JpaRepository<AadApplication, Integer> {
	
	public List<AadApplication> findByStatus(String status); 
	public AadApplication findByCid(int cid);
	public List<AadApplication> findByType(String type); 

}
