package com.Aadhar.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Aadhar.models.AadCard;
import com.Aadhar.repo.AadCardRepo;

@Service
public class AadCardServiceImp implements AadCardService {
	
	@Autowired
	AadCardRepo carepo;

	@Override
	public String AddNewCard(AadCard card) {
		String res = "err";
		if(card!=null)
		{
			carepo.save(card);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public List<AadCard> ShowAllCards() {
		List<AadCard>  cardall = carepo.findAll();
		return cardall;
	}

	@Override
	public AadCard SearchCard(int aadid) {
		Optional<AadCard> card = carepo.findById(aadid);
		if(card.isPresent())
			return card.get();
		
		return null;
	}

	@Override
	public String UpdateCard(AadCard card) {
		String res = "err";
		if(card!=null)
		{
			carepo.saveAndFlush(card);  // modify
			res = "Success";
		}
		return res;
	}

	@Override
	public void DeleteCard(int aadid) {
		carepo.deleteById(aadid);
		
	}

	@Override
	public AadCard findByAadcid(int aadcid) {
		AadCard card = carepo.findByAadcid(aadcid);
		if(card!=null)
			return card;
		
		return null;
	}
	
}
