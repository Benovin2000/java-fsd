package com.Aadhar.models;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="AadCardInfo")
public class AadCard {
	
	@Id
	@GeneratedValue
	private int aadid;
	
	private int aadcid;
	private String issuedate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
	private int duplicate;
	
	public int getAadid() {
		return aadid;
	}
	public void setAadid(int aadid) {
		this.aadid = aadid;
	}
	public int getAadcid() {
		return aadcid;
	}
	public void setAadcid(int aadcid) {
		this.aadcid = aadcid;
	}
	public String getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}
	public int getDuplicate() {
		return duplicate;
	}
	public void setDuplicate(int duplicate) {
		this.duplicate = duplicate;
	}
	
	


}