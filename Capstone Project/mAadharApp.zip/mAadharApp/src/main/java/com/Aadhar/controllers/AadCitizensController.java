package com.Aadhar.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.Aadhar.Service.AadApplicationService;
import com.Aadhar.Service.AadCardService;
import com.Aadhar.Service.AadCitizensService;
import com.Aadhar.models.AadApplication;
import com.Aadhar.models.AadCard;
import com.Aadhar.models.AadCitizens;


@Controller
public class AadCitizensController {

		@Autowired
		AadCitizensService  Acs;
		
		@Autowired
		AadCardService  cas;
		
		@Autowired
		AadApplicationService  aps;
		
		@GetMapping(value="/citlogin")
		public String Login(Model m)
		{
			m.addAttribute("aadcit", new AadCitizens ());
			return "login2";
		}
		
		@GetMapping(value="/Register2")
		public String NewUser(Model m)
		{
			m.addAttribute("aadcit", new AadCitizens ());
			return "AadCitizensReg";
		}
		
		 @PostMapping(value="/addAadCit")
		public String NewUser(@ModelAttribute("aadcit") AadCitizens user,
				Model m)
		{
			if(Acs.AddNewCitizen(user).equals("Success")) {
				
				m.addAttribute("aadcit", new AadCitizens());
				m.addAttribute("msg", "Registered Sucessfully!");
			}
			return "login2";
		}

		 
		@PostMapping(value="/CheckCitizenLogin")
		public String CheckLogin(@RequestParam("name") 	String name, @RequestParam("password") String password, RedirectAttributes redirAttr,
				Model m) throws Exception
		{
			try {
				AadCitizens check = Acs.findByName(name);
			if(check.getName().equals(name) && check.getMobileno().equals(password)) 
				{
					m.addAttribute("aadcit", new AadCitizens());
					m.addAttribute("msg", "Logged in Successfully!");
					redirAttr.addAttribute("cit", check.getName());
					return "redirect:/aadcitizen";
				}
			else {
					m.addAttribute("msg", "Incorrect Credentials!");
					m.addAttribute("aadcit", new AadCitizens()); 
					return "citlogin";
				}
				
				}
			 catch(Exception e) 
				{
				 	m.addAttribute("msg", "Incorrect Credentials!");
				 	m.addAttribute("aadcit", new AadCitizens());
				 	return "citlogin";
				}
		}

		@GetMapping(value="/aadcitizen")
		public String ViewCitizen(Model m, @RequestParam("cit") String name)
		{
			AadCitizens cit = Acs.findByName(name);
			AadCard card = cas.findByAadcid(cit.getAadcid());
			AadApplication app = aps.findByCid(cit.getAadcid());
			m.addAttribute("app", app);
			m.addAttribute("cit", cit);
			m.addAttribute("card", card);
			return "aadCitizensHome";
		}
		
		@GetMapping(value="/applyCard")
		public String ApplyingForAadhar(Model m, @RequestParam("aadcid") int aadcid, RedirectAttributes redirAttr)
		{
			AadApplication apply = new AadApplication();
			AadCitizens cit = Acs.SearchCitizen(aadcid);
			apply.setCid(aadcid);
	if(aps.AddNewApplication(apply).equals("Success")) {
				
		redirAttr.addAttribute("apply", new AadApplication());
		redirAttr.addAttribute("cit", cit.getName());
		redirAttr.addAttribute("msg", "Applied Sucessfully!");
			}
			return "redirect:/aadcitizen";
		}
		
		@GetMapping(value="/upCit")
		public String UpdateCitizen(@RequestParam("aadcid") int cid, Model m)
		{
			AadCitizens cit = Acs.SearchCitizen(cid);
			m.addAttribute("cit", cit);
			return "aadCitizenUpdate";
		}
		
		@PostMapping(value="updatedCit")
		public String ModifyCitizen(@ModelAttribute("cit") AadCitizens cit, RedirectAttributes redirAttr,
				Model m)
		{
			Acs.ModifyCitizen(cit);		
			AadCard card = cas.findByAadcid(cit.getAadcid());
			AadApplication app = aps.findByCid(cit.getAadcid());
			redirAttr.addAttribute("app", app);
			redirAttr.addAttribute("cit", cit.getName());
			redirAttr.addAttribute("card", card);
			return "redirect:/aadcitizen";
		}
		
		@GetMapping(value="/applycopy")
		public String ApplyDuplicate(Model m, @RequestParam("aadcid") int aadcid, RedirectAttributes redirAttr)
		{
			AadApplication apply = aps.findByCid(aadcid);
			AadCitizens cit = Acs.SearchCitizen(aadcid);
			apply.setType("Duplicate");
	if(aps.UpdateApplication(apply).equals("Success")) {
				
				redirAttr.addAttribute("apply", new AadApplication());
				redirAttr.addAttribute("cit", cit.getName());
				redirAttr.addAttribute("msg", "Applied Sucessfully!");
			}
			return "redirect:/aadcitizen";
		}
}