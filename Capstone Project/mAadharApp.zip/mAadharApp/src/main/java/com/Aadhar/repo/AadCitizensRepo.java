package com.Aadhar.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Aadhar.models.AadCitizens;

@Repository
public interface AadCitizensRepo extends JpaRepository<AadCitizens, Integer> {
	
	public AadCitizens findByName(String name);
}
