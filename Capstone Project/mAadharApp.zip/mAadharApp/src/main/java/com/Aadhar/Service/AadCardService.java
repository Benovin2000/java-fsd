package com.Aadhar.Service;

import java.util.List;

import com.Aadhar.models.AadCard;

public interface AadCardService {

	public String AddNewCard(AadCard card);
	public List<AadCard> ShowAllCards();
	public AadCard  SearchCard(int aadid);
	public String UpdateCard(AadCard card);
	public void DeleteCard(int aadid);
	public AadCard findByAadcid(int aadcid);
}
