package com.Aadhar.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Aadhar.models.AadApplication;
import com.Aadhar.models.AadCitizens;
import com.Aadhar.repo.AadApplicationRepo;

 
@Service
public class AadApplicationServiceImp implements AadApplicationService {

	@Autowired
	AadApplicationRepo aprepo;
	
	@Override
	public String AddNewApplication(AadApplication app) {
		String res = "err";
		if(app!=null)
		{
			aprepo.save(app);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public List<AadApplication> ShowAllApplications() {
		List<AadApplication>  appall = aprepo.findAll();
		return appall;
	}

	@Override
	public AadApplication SearchApplication(int appid) {
		Optional<AadApplication> app = aprepo.findById(appid); 
		if(app.isPresent())
			return app.get();
		
		return null;
	}

	@Override
	public String UpdateApplication(AadApplication app) {
		String res = "err";
		if(app!=null)
		{
			aprepo.saveAndFlush(app);  // modify
			res = "Success";
		}
		return res;
	
	}

	@Override
	public void DeleteApplication(int appid) {
		aprepo.deleteById(appid);
		
	}

	@Override
	public List<AadApplication> findByStatus(String status) {
		List<AadApplication>  applied = aprepo.findByStatus("applied");
		if(applied!=null)
			return applied;
		
		return null;
	}

	@Override
	public AadApplication findByCid(int cid) {
		AadApplication app = aprepo.findByCid(cid);
		if(app!=null)
			return app;
		
		return null;
	}

	@Override
	public List<AadApplication> findByType(String type) {
		List<AadApplication>  copy = aprepo.findByType("Duplicate");
		if(copy!=null)
			return copy;
		
		return null;
	}

}
