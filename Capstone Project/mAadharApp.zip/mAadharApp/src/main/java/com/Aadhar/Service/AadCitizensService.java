package com.Aadhar.Service;

import java.util.List;

import com.Aadhar.models.AadCitizens;


public interface AadCitizensService {
	
	public String AddNewCitizen(AadCitizens cit);
	public List<AadCitizens> ShowAllCitizens();
	public AadCitizens  SearchCitizen(int cid);
	public AadCitizens findByName(String name);
	public String ModifyCitizen(AadCitizens cit);
	public void DeleteCitizen(int cid);

}
