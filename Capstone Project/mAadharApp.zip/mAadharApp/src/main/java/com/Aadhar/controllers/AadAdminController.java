package com.Aadhar.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Aadhar.Service.AadApplicationService;
import com.Aadhar.Service.AadCardService;
import com.Aadhar.Service.AadCitizensService;
import com.Aadhar.models.AadApplication;
import com.Aadhar.models.AadCard;
import com.Aadhar.models.AadCitizens;

@Controller
public class AadAdminController {

		@Autowired
		AadCitizensService  Acs;
		
		@Autowired
		AadCardService  cas;
		
		@Autowired
		AadApplicationService  aps;
		
		
		@GetMapping(value="/adminlogin")
		public String AdminLogin(Model m)
		{
			m.addAttribute("aadcit", new AadCitizens ());
			return "adminlogin";
		}
		
		@PostMapping(value="/CheckAdminLogin")
		public String CheckAdminLogin(@RequestParam("name") String name, @RequestParam("password") String password,
				Model m) throws Exception {
			
			if(name.equalsIgnoreCase("admin") && password.equals("Admin@123")) {
				m.addAttribute("aadcit", new AadCitizens());
				m.addAttribute("msg", "Logged in Successfully!");
				return "redirect:/aadAdminHome";
			}
			else {
					m.addAttribute("msg", "Incorrect Credentials!");
					m.addAttribute("aadcit", new AadCitizens()); 
					return "adminlogin";
				}
				
				}
		
		@GetMapping(value="/aadAdminHome")
		public String AdminHome(Model m)
		{
			List<AadApplication> applied = aps.findByStatus("applied");
			List<AadApplication> copy = aps.findByType("Duplicate");
			List<AadCard> cards = cas.ShowAllCards();
			int size = applied.size() + copy.size();
			m.addAttribute("applied", applied);
			m.addAttribute("copy", copy);
			m.addAttribute("size", size);
			m.addAttribute("cards", cards);
			return "aadAdminHome";
		}
		
		@GetMapping(value="/approveCard")
		public String ApproveCard(@RequestParam ("aadcid") int aadcid, Model m)
		{
			
			AadApplication app = aps.findByCid(aadcid);
			app.setStatus("Approved");
			aps.UpdateApplication(app);
			AadCard card = new AadCard();
			card.setAadcid(aadcid);
			cas.AddNewCard(card);
			return "redirect:/aadAdminHome";
		}
		
		@GetMapping(value="/deleteRequest")
		public String DeleteRequest(@RequestParam("appid") int appid)
		{
			aps.DeleteApplication(appid);
			return "redirect:/aadAdminHome";
		}
		
		@GetMapping(value="/deleteCard")
		public String DeleteCard(@RequestParam("aadid") int aadid)
		{
			cas.DeleteCard(aadid);
			return "redirect:/aadAdminHome";
		}
		
		@GetMapping(value="/approveCopy")
		public String ApproveCopy(@RequestParam ("aadcid") int aadcid, Model m)
		{
			
			AadApplication app = aps.findByCid(aadcid);
			app.setType("Issued Duplicate");
			aps.UpdateApplication(app);
			AadCard card = cas.findByAadcid(aadcid);
			card.setDuplicate(1);
			cas.UpdateCard(card);
			return "redirect:/aadAdminHome";
		}
		
		
}
