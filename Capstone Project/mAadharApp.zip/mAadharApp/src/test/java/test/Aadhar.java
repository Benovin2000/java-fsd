package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Aadhar {

	private WebDriver driver=null;
	
	
	@BeforeTest
	public void InitalizeDriver() {
	
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();	
	}
	
	 @Test(priority=1)
	public void LaunchingWebsite() {
		
		driver.get("http://localhost:4200/citlogin");
		//driver.findElement(By.xpath("//a[@href='/pages/terms' ]")).sendKeys(Keys.ESCAPE);
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
