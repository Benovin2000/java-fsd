package assistedPracticeProjects.Set1;


	abstract class AnonymousInnerClass {
		   public abstract void display();
		}



