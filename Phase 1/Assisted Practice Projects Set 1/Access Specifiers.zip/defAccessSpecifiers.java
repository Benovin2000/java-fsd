package assistedPracticeProjects.Set1;

public class defAccessSpecifiers {

	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessSpecifier1 obj = new defAccessSpecifier1(); 		  
        obj.display(); 

	}
}

