package assistedPracticeProjects.Set1;

class priAccessspecifier1 {
	private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 

