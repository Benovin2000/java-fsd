package assistedPracticeProjects.Set1;

public class priAccessspecifier {
	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		priAccessspecifier1  obj = new priAccessspecifier1(); 
        //trying to access private method of another class 
        obj.display();

	}
}




