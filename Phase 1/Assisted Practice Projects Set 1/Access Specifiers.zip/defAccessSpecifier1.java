package assistedPracticeProjects.Set1;

class defAccessSpecifier1
{ 
  void display() 
     { 
         System.out.println("You are using default access specifier"); 
     }

public static void main(String[] args) {
	regularExpnAssisted
} 
} 



