package assistedPracticeProjects.Set1;

public class pubaccessspecifiers {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}



