package assistedPracticeProjects.Set1;

class EmpInfo {
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}
