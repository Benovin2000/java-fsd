package assistedPracticeProjects.Set2;

public class Main 
{ 
    public static void main(String args[]) 
    { 
        try
        { 
            throw new MyException1("temp"); 
        } 
        catch (MyException1 ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 
    } 
}
