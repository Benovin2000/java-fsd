package assistedPracticeProjects.Set2;

class MyException1 extends Exception 
{ 
    public MyException1(String s) 
    { 
        super(s); 
    } 
} 


