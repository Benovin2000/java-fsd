package com.vaccination.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccination.models.citizens;
import com.vaccination.models.users;
import com.vaccination.repo.citizenRepo;

@Service
public class citizenServiceImp implements citizenService {
	
	@Autowired
	citizenRepo cir;

	@Override
	public String AddNewCitizen(citizens cit) {
		String res = "err";
		if(cit!=null)
		{
			cir.save(cit);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public List<citizens> ShowAllCitizens() {
		List<citizens>  citall = cir.findAll();
		return citall;
	}

	@Override
	public citizens SearchCitizen(int cid) {
		Optional<citizens> cit = cir.findById(cid); 
		if(cit.isPresent())
			return cit.get();
		
		return null;
	}

	@Override
	public String ModifyCitizen(citizens cit) {
		String res = "err";
		if(cit!=null)
		{
			cir.saveAndFlush(cit);  // modify
			res = "Success";
		}
		return res;
	}

	@Override
	public void DeleteCitizen(int cid) {
		cir.deleteById(cid);
		
	}
	
	@Override
	public citizens findBycitcname(String citcname) {
		citizens cit = cir.findBycitcname(citcname);
		if(cit!=null)
			return cit;
		
		return null;
	}

}
