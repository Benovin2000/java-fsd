package com.vaccination.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vaccination.models.citizens;
import com.vaccination.models.users;

@Repository
public interface citizenRepo extends JpaRepository<citizens, Integer>{
	
	public citizens findBycitcname(String citcname);
	
}

