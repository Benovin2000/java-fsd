package com.vaccination.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="citizenInfo")
public class citizens {
	
	@Id
	@GeneratedValue
	@PrimaryKeyJoinColumn
	private int cid;
	
	private String cname;
	private int doses;
	private String status = "Not Vaccinated";
	private String citcname;
	private String citcity;
	
	@OneToOne(targetEntity = centers.class, cascade=CascadeType.MERGE)
	private centers cen;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getDoses() {
		return doses;
	}

	public void setDoses(int doses) {
		this.doses = doses;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public centers getCen() {
		return cen;
	}

	public void setCen(centers cen) {
		this.cen = cen;
	}

	public String getCitcname() {
		return citcname;
	}

	public void setCitcname(String citcname) {
		this.citcname = citcname;
	}

	public String getCitcity() {
		return citcity;
	}

	public void setCitcity(String citcity) {
		this.citcity = citcity;
	}
	
}
