package com.vaccination.service;

import java.util.List;

import com.vaccination.models.users;

public interface userService {
	
	public String AddNewUser(users us);
	public users findByEmail(String email);
	public users  SearchUser(int uid);

}
