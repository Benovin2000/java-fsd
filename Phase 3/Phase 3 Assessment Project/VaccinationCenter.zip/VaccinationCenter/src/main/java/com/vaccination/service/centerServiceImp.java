package com.vaccination.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccination.models.centers;
import com.vaccination.repo.centerRepo;

@Service
public class centerServiceImp implements centerService {
	
	@Autowired
	centerRepo cer;

	@Override
	public String AddNewCenter(centers cen) {
		String res = "err";
		if(cen!=null)
		{
			cer.save(cen);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public List<centers> ShowAllCenters() {
		List<centers>  cenall = cer.findAll();
		return cenall;
	}

	@Override
	public centers SearchCenter(int cenid) {
		Optional<centers> cen = cer.findById(cenid); 
		if(cen.isPresent())
			return cen.get();
		
		return null;
	}

	@Override
	public String ModifyCenter(centers cen) {
		String res = "err";
		if(cen!=null)
		{
			cer.saveAndFlush(cen);  // modify
			res = "Success";
		}
		return res;
	}

	@Override
	public void DeleteCenter(int cenid) {
		cer.deleteById(cenid);
		
	}

}
