package com.vaccination.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vaccination.models.centers;
import com.vaccination.models.citizens;
import com.vaccination.service.centerService;
import com.vaccination.service.citizenService;

@Controller
public class citizenController {

	@Autowired
	citizenService  cs;
	
	@Autowired
	centerService censer;

	 @GetMapping(value="/citizens")
	public String CitzenHome(Model m)
	{
		List<citizens> citAll = cs.ShowAllCitizens();
		int size = citAll.size();
		List<centers> cenAll = censer.ShowAllCenters();
		m.addAttribute("size", size);
		m.addAttribute("cenall", cenAll);
		m.addAttribute("call", citAll);
		return "citizen";
	}
	 
	
	@GetMapping(value="/addCitizen")
	public String NewCitizen(Model m)
	{
		List<centers> cenAll = censer.ShowAllCenters();
		m.addAttribute("cenall", cenAll);
		m.addAttribute("cit", new citizens());
		return "addCitizen";
	}
	
	@PostMapping(value="/addedCitizen")
	public String NewCitizen(@RequestParam("cname") String cname,
			@RequestParam("centerid") String centerid,
			@RequestParam("citcity") String citcity,
			@RequestParam("citcname") String citcname,
			Model m)
	{		
			citizens cit = new citizens();
			int cenid = Integer.parseInt(centerid.substring(0, centerid.indexOf("*")));
		
			centers cent = new centers();
			cent.setCenid(cenid);
		
			cit.setCname(cname);
			cit.setCitcname(citcname);
			cit.setCitcity(centerid.substring(centerid.indexOf("*")+1));
			cit.setCen(cent);
			
			
			
		if(cs.AddNewCitizen(cit).equals("Success"))
		{
			m.addAttribute("cen", new centers());
			m.addAttribute("cit", new citizens());
			m.addAttribute("msg", "Citizen Info Added...");
		}
		return "redirect:/citizens";
	}

	@GetMapping(value="/delcitizen")
	public String DelCitizen(@RequestParam("cid") int cid)
	{
		cs.DeleteCitizen(cid);
		return "redirect:/citizens";
	}
	
	
	@GetMapping(value="/modcitizen")
	public String UpdateCitizen(@RequestParam("cid") int cid, Model m)
	{
		citizens cit = cs.SearchCitizen(cid);
		List<centers> cenAll = censer.ShowAllCenters();
		m.addAttribute("cenall", cenAll);
		m.addAttribute("cit", cit);
		return "editCitizen";
	}
		
	@PostMapping(value="/modifiedcitizen")
	public String ModifyCitizen(@ModelAttribute("cit") citizens cit,
			Model m)
	{
		if(cit.getDoses()==0)
			cit.setStatus("Not Vaccinated");
		if(cit.getDoses()==1)
			cit.setStatus("Not Fully Vaccinated");
		if(cit.getDoses()==2)
			cit.setStatus("Fully Vaccinated");

		cs.ModifyCitizen(cit);
		
		return "redirect:/citizens";
	} 
	
	@GetMapping(value="/citizen")
	public String ViewCitizen(@RequestParam("cid") int cid, Model m)
	{
		citizens cit = cs.SearchCitizen(cid);
		m.addAttribute("cit", cit);
		return "viewCitizen";
	}
} 
