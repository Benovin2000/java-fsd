package com.vaccination.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vaccination.models.centers;
import com.vaccination.models.citizens;
import com.vaccination.service.centerService;
import com.vaccination.service.citizenService;

@Controller
public class centerController {

	@Autowired
	centerService  cs;
	
	@Autowired
	citizenService cis;

	 @GetMapping(value="/vaccinationcenters")
	public String HomePage(Model m)
	{
		List<centers> cenAll = cs.ShowAllCenters();
		int size = cenAll.size();
		m.addAttribute("call", cenAll);
		m.addAttribute("size", size);
		return "vaccinationHome";
	}
		
	
	 @GetMapping(value="/addCenter")
	public String NewCenter(Model m)
	{
		m.addAttribute("cen", new centers());
		return "addCenter";
	}
	
	@PostMapping(value="/addedCenter")
	public String NewCenter(@ModelAttribute("cen") centers cen,
			Model m)
	{		
		if(cs.AddNewCenter(cen).equals("Success"))
		{
			m.addAttribute("cen", new centers());
			m.addAttribute("msg", "Vaccination Center Added...");
		}
		return "redirect:/vaccinationcenters";
	}
	
	@GetMapping(value="/vaccinationcenter")
	public String ViewCenter(@RequestParam("cenid") int cenid, Model m)
	{
		centers cen = cs.SearchCenter(cenid);
		citizens cit = cis.findBycitcname(cen.getCenname());
		m.addAttribute("cit", cit);
		m.addAttribute("cen", cen);
		return "viewCenter";
	}
	
	@GetMapping(value="/del")
	public String DeleteCenter(@RequestParam("cenid") int cenid)
	{
		cs.DeleteCenter(cenid);
		return "redirect:/vaccinationcenters";
	}
	
	@GetMapping(value="/mod")
	public String UpdateCenter(@RequestParam("cenid") int cenid, Model m)
	{
		centers cen = cs.SearchCenter(cenid);
		m.addAttribute("cen", cen);
		return "editCenter";
	}
		
	@PostMapping(value="/modn")
	public String ModifyCenter(@ModelAttribute("cen") centers cen,
			Model m)
	{
		cs.ModifyCenter(cen);	
		return "redirect:/vaccinationcenters";
	}
}

