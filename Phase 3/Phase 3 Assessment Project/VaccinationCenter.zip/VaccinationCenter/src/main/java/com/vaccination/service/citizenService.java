package com.vaccination.service;

import java.util.List;

import com.vaccination.models.citizens;

public interface citizenService {
	
	public String AddNewCitizen(citizens cit);
	public List<citizens> ShowAllCitizens();
	public citizens  SearchCitizen(int cid);
	public String ModifyCitizen(citizens cit);
	public void DeleteCitizen(int cid);
	public citizens findBycitcname(String citcname);

}
