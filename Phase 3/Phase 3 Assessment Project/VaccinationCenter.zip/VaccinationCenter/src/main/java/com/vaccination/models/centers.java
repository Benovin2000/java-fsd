package com.vaccination.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="centerInfo")
public class centers {
	
	@Id
	@GeneratedValue
	private int cenid;
	
	private String cenname;
	private String cencity;
	
	public int getCenid() {
		return cenid;
	}
	public void setCenid(int cenid) {
		this.cenid = cenid;
	}
	public String getCenname() {
		return cenname;
	}
	public void setCenname(String cenname) {
		this.cenname = cenname;
	}
	public String getCencity() {
		return cencity;
	}
	public void setCencity(String cencity) {
		this.cencity = cencity;
	}
	
}
