package com.vaccination.service;

import java.util.List;

import com.vaccination.models.centers;

public interface centerService {
		
		public String AddNewCenter(centers cen);
		public List<centers> ShowAllCenters();
		public centers  SearchCenter(int cenid);
		public String ModifyCenter(centers cen);
		public void DeleteCenter(int cenid);

	}

	

