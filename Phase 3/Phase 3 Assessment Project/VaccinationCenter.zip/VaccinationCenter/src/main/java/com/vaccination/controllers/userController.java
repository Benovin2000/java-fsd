package com.vaccination.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vaccination.service.userService;
import com.vaccination.models.*;

@Controller
public class userController {

		@Autowired
		userService  us;
		
		@GetMapping(value="/login")
		public String Login(Model m)
		{
			m.addAttribute("usr", new users ());
			return "login";
		}
		
		@GetMapping(value="/Register")
		public String NewUser(Model m)
		{
			m.addAttribute("usr", new users ());
			return "userReg";
		}
		
		@PostMapping(value="/addn")
		public String NewUser(@ModelAttribute("usr") users user,
				Model m)
		{
			if(us.AddNewUser(user).equals("Success")) {
				
				m.addAttribute("usr", new users());
				m.addAttribute("msg", "User Registered Sucessfully!");
			}
			return "login";
		}

		@PostMapping(value="/CheckLogin")
		public String CheckLogin(@RequestParam("txtemail") 	String email, @RequestParam("txtpassword") String password,
				Model m) throws Exception
		{
			try {
			users check = us.findByEmail(email);
			if(check.getEmail().equals(email) && check.getPassword().equals(password)) 
				{
					m.addAttribute("usr", new users());
					m.addAttribute("msg", "Logged in Successfully!");
					return "redirect:/vaccinationcenters";
				}
			else {
					m.addAttribute("msg", "Incorrect Credentials!");
					m.addAttribute("usr", new users()); 
					return "login";
				}
				
				}
			 catch(Exception e) 
				{
				 	m.addAttribute("msg", "Incorrect Credentials!");
				 	m.addAttribute("usr", new users());
				 	return "login";
				}
		}
}