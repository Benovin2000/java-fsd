package com.vaccination.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccination.models.users;
import com.vaccination.repo.userRepo;

@Service
public class userServiceImp implements userService {
	
	@Autowired
	userRepo urepo;

	@Override
	public String AddNewUser(users us) {
		String res = "err";
		if(us!=null)
		{
			urepo.save(us);  // add
			res = "Success";
		}
		return res;
	}

	@Override
	public users SearchUser(int uid) {
		Optional<users> us = urepo.findById(uid); 
		if(us.isPresent())
			return us.get();
		
		return null;
	}

	@Override
	public users findByEmail(String email) {
		users us = urepo.findByEmail(email);
		if(us!=null)
			return us;
		
		return null;
	}
	
	
	

}
